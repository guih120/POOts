export class Location {
    constructor(
        public latitude: number,
        public longitude: number
    ) {}
}